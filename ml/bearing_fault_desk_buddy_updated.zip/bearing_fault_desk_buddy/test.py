import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score, confusion_matrix, classification_report,
    precision_recall_fscore_support
)

def evaluate(test_dl, model, class_names=None):
    device = next(model.parameters()).device
    model.eval()
    predictions, labels = [], []

    with torch.no_grad():
        for x, y in test_dl:
            logits = model(x.to(device))
            predictions.extend(logits.argmax(1).cpu().numpy().tolist())
            labels.extend(y.numpy().tolist())

    if class_names is None:
        class_names = [str(i) for i in range(model.predictor[-1].out_features)]

    accuracy = accuracy_score(labels, predictions) * 100.0
    cm = confusion_matrix(labels, predictions, labels=list(range(len(class_names))))
    report = classification_report(
        labels, predictions, labels=list(range(len(class_names))),
        target_names=class_names, zero_division=0, output_dict=True
    )
    print(f"Test accuracy: {accuracy:.2f}%")
    print(classification_report(
        labels, predictions, labels=list(range(len(class_names))),
        target_names=class_names, zero_division=0
    ))
    return {
        "accuracy": accuracy,
        "labels": np.asarray(labels),
        "predictions": np.asarray(predictions),
        "confusion_matrix": cm,
        "classification_report": report
    }
