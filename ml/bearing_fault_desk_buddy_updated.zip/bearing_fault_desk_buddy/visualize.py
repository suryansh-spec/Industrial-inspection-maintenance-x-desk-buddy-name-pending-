from pathlib import Path
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import ConfusionMatrixDisplay

def save_training_plots(history, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    epochs = range(1, len(history["train_loss"]) + 1)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    axes[0].plot(epochs, history["train_loss"], label="Train")
    axes[0].plot(epochs, history["valid_loss"], label="Validation")
    axes[0].set(title="Training and validation loss", xlabel="Epoch", ylabel="Cross-entropy loss")
    axes[0].grid(True, alpha=0.3); axes[0].legend()

    axes[1].plot(epochs, history["train_accuracy"], label="Train")
    axes[1].plot(epochs, history["valid_accuracy"], label="Validation")
    axes[1].set(title="Training and validation accuracy", xlabel="Epoch", ylabel="Accuracy (%)")
    axes[1].set_ylim(0, 100); axes[1].grid(True, alpha=0.3); axes[1].legend()
    fig.tight_layout()
    fig.savefig(output_dir / "training_curves.png", dpi=160)
    plt.close(fig)

    with open(output_dir / "training_history.json", "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2)

def save_evaluation_plots(metrics, class_names, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(7, 6))
    display = ConfusionMatrixDisplay(
        confusion_matrix=metrics["confusion_matrix"],
        display_labels=class_names
    )
    display.plot(ax=ax, cmap="Blues", values_format="d", colorbar=False)
    ax.set_title(f"Test confusion matrix — {metrics['accuracy']:.2f}% accuracy")
    fig.tight_layout()
    fig.savefig(output_dir / "confusion_matrix.png", dpi=160)
    plt.close(fig)

    report = metrics["classification_report"]
    rows = []
    for name in class_names:
        item = report[name]
        rows.append([name, item["precision"], item["recall"], item["f1-score"], item["support"]])
    fig, ax = plt.subplots(figsize=(9, 3.5))
    ax.axis("off")
    table = ax.table(
        cellText=[[r[0], *[f"{v:.3f}" if isinstance(v, float) else str(v) for v in r[1:]]] for r in rows],
        colLabels=["Class", "Precision", "Recall", "F1-score", "Support"],
        loc="center", cellLoc="center"
    )
    table.auto_set_font_size(False); table.set_fontsize(10); table.scale(1, 1.5)
    ax.set_title("Per-class test metrics", pad=18)
    fig.tight_layout()
    fig.savefig(output_dir / "class_metrics.png", dpi=160, bbox_inches="tight")
    plt.close(fig)

    with open(output_dir / "classification_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
