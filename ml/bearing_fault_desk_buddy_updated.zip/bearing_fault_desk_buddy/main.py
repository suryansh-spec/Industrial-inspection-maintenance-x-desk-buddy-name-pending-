from pathlib import Path
import json
import torch

from arguments import get_args
from dataset import get_dataloaders
from train import train_model
from test import evaluate
from preprocess import CWRUPreprocessor
from visualize import save_training_plots, save_evaluation_plots

def main():
    opt = get_args()
    project_dir = Path(__file__).resolve().parent
    data_path = project_dir / "raw_data"
    output_dir = project_dir / opt.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    # These four files represent one example recording for each class.
    data_list = ["97.mat", "105.mat", "118.mat", "130.mat"]
    data_info = ["X097_DE_time", "X105_DE_time", "X118_DE_time", "X130_DE_time"]
    class_names = ["Normal", "Inner Race", "Ball", "Outer Race"]
    window_size = 1200

    preprocessor = CWRUPreprocessor(
        data_dir=str(data_path),
        data_list=data_list,
        data_info=data_info,
        condition_list=class_names,
        window_size=window_size,
        num_data=4000
    )
    X, y = preprocessor.get_data()
    print(f"Prepared {len(X)} windows; input shape: {X.shape}")

    # One-hot labels are used by the original split interface.
    Y = __import__("numpy").eye(len(class_names))[y]
    train_dl, valid_dl, test_dl = get_dataloaders(X, Y, opt)

    model, history = train_model(opt, train_dl, valid_dl, num_classes=len(class_names))
    metrics = evaluate(test_dl, model, class_names)

    save_training_plots(history, output_dir)
    save_evaluation_plots(metrics, class_names, output_dir)

    checkpoint = {
        "model_state_dict": model.state_dict(),
        "class_names": class_names,
        "window_size": window_size,
        "input_channels": 1,
        "architecture": "CNNModel-1D",
        "dataset": "CWRU",
        "best_epoch": history["best_epoch"],
        "test_accuracy": metrics["accuracy"]
    }
    checkpoint_path = output_dir / "best_model.pth"
    torch.save(checkpoint, checkpoint_path)

    summary = {
        "test_accuracy": metrics["accuracy"],
        "best_epoch": history["best_epoch"],
        "class_names": class_names,
        "window_size": window_size
    }
    with open(output_dir / "evaluation_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    print(f"\\nModel saved: {checkpoint_path}")
    print(f"Visualizations and metrics saved in: {output_dir}")
    print("Backend usage: from inference import BearingFaultPredictor")

if __name__ == "__main__":
    main()
